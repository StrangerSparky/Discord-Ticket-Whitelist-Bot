// colors.js
module.exports = {
    red: 0xFF0000,
    green: 0x00FF00,
    blue: 0x0000FF,
    yellow: 0xFFFF00,
    purple: 0x9400D3,
    pink: 0xFFC0CB,
    orange: 0xFFA500,
    cyan: 0x00FFFF,
    brown: 0x964B00,
    white: 0xFFFFFF,
    black: 0x000000,
    gray: 0x808080,
    gold: 0xFFD700,
    blurple: 0x5865F2,
    aqua: 0x00FFFF,
    lime: 0x32CD32,
    magenta: 0xFF00FF,
    violet: 0x8F00FF,
    indigo: 0x4B0082,
    default: 0x0099FF
};